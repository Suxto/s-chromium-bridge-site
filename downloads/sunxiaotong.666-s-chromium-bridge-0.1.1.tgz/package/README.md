# `@sunxiaotong.666/s-chromium-bridge`

A local, authenticated bridge for controlling the **existing** Google Chrome or Microsoft Edge session and applying scoped ENV rules. It consists of:

- a clean-room Manifest V3 extension;
- a Chrome Native Messaging host;
- a loopback JSON-RPC server and CLI;
- an **ENV** popup tab for profiles and a **Host** popup tab for browser-control permissions and approvals.

It does not start a separate browser profile, export cookies/history/passwords, or contain an AI model, chat UI, recorder, or side panel.

## Requirements

- Node.js `>=22.19`
- macOS or Linux
- Google Chrome or Microsoft Edge

## Install

Install from the public reviewer package (or from the npm registry after a public release):

```bash
npm install --global https://suxto.github.io/s-chromium-bridge-site/downloads/sunxiaotong.666-s-chromium-bridge-0.1.1.tgz
s-chromium-bridge install-host
s-chromium-bridge extension-path
```

1. Open `chrome://extensions` or `edge://extensions`.
2. Enable **Developer mode**.
3. Choose **Load unpacked** and select the directory printed by `extension-path`.
4. Open the extension popup. Set a user-wide **Browser instance alias** (for example, `work-chrome`) and the preferred localhost port if needed (default `11451`), then enable **Settings → Native Host bridge** only when browser control is needed. Alias registration requires a connected Native Host, is unique across Chrome, Edge, and browser profiles for the current OS user, and is normalized to lowercase. The compact switch beside **Profiles** pauses or resumes request-rule injection without blocking profile edits or changing each profile's own enabled state. The popup language defaults to **Auto**, which follows Chrome or Edge's UI language—Chinese for a Chinese browser UI and English otherwise; users can persist **Auto**, **English**, or **简体中文** under **Settings → Language**.

HTTP(S) page access is requested from Chrome only when the user enables the Native Host bridge or request modification after accepting the browser-data disclosure. Protected ENV profile-deletion approvals are enabled by default and can be disabled with **Host → Agent approvals**; when disabled, those operations run immediately and the pending-approval panel is hidden. Raw `page.cdp.send` is separately disabled by default and requires the popup's dangerous **Full CDP access** switch.

Verify the installation:

```bash
s-chromium-bridge doctor
s-chromium-bridge status
```

The unpacked development extension ID is fixed at `cdffpbdlnhgagimbmogbigjdnmmlmkic`; the Chrome Web Store ID is `offaafgamboghokfkobpkhfjfbaokhjl`. The Native Messaging manifest permits both exact IDs. The Native Messaging host name is `com.sunxiaotong.s_chromium_bridge`.

## CLI

```text
s-chromium-bridge status [--instance <id> | --alias <name> | --browser chrome|edge] [--json]
s-chromium-bridge call <method> [--params <json|@file>] [--session <id>]
                           [--instance <id> | --alias <name> | --browser chrome|edge]
                           [--timeout <ms>] [--request-id <id>] [--client <id>] [--json]
s-chromium-bridge install-host [--browser chrome|edge|all] [--json]
s-chromium-bridge uninstall-host [--browser chrome|edge|all] [--purge] [--json]
s-chromium-bridge extension-path
s-chromium-bridge doctor [--json]
```

Use `--instance`, `--alias`, or `--browser` as mutually exclusive instance selectors. Aliases match `^[a-z0-9][a-z0-9._-]{0,63}$`, bind to the persistent extension `instanceId` rather than a temporary control session, and never fall back to another browser when their instance is offline. Use `--client <stable-id>` for long-lived automation that owns sessions or transfers. Without it, the CLI uses a random client identity persisted in the mode-`0600` local config so separate invocations remain ownership-compatible. Concurrent agents should always supply distinct stable IDs. Use `--request-id <id>` when another process may need to cancel a running call with `s-chromium-bridge cancel <id>`.

Open a session on the current active tab:

```bash
s-chromium-bridge call session.open \
  --alias work-chrome \
  --params '{"mode":"current","retention":"none"}' --json
```

Inspect tabs and take an accessibility-first snapshot:

```bash
s-chromium-bridge call browser.tabs.list --session "$SESSION_ID" --json
s-chromium-bridge call page.snapshot \
  --session "$SESSION_ID" \
  --params '{"tabId":123,"mode":"full","maxNodes":500}' --json
s-chromium-bridge call page.snapshot.diff \
  --session "$SESSION_ID" \
  --params '{"tabId":123,"maxNodes":500}' --json
s-chromium-bridge call page.click \
  --session "$SESSION_ID" \
  --params '{"tabId":123,"locator":{"role":"button","name":"Save","exact":true}}' --json
```

High-level page actions accept a fresh semantic `locator` as an alternative to a snapshot `ref` or explicit CSS `selector`. Locators can combine accessible role/name, label, placeholder, visible non-editable text, test ID, and states; they support explicit `nth` and fail closed when zero or multiple elements match. `page.locate` returns bounded matches when an agent wants to inspect before acting. Dedicated `focus`, `hover`, `check`, `uncheck`, and `select` methods cover common interactions without raw script or CDP calls. A click, double-click, or key press that is expected to navigate can set `waitForNavigation: true`; the bridge registers navigation listeners before the action, waits for action plus main-frame commit/history/fragment completion, and returns the refreshed live-tab navigation result without creating a replacement tab. Raw `page.cdp.send` is available only when the popup's dangerous **Full CDP access** switch is enabled.

`page.snapshot.diff` compares with the latest same-session snapshot for the same document generation and returns bounded `added`, `removed`, `changed`, focus, URL, and title transitions. A first call or navigation creates a fresh baseline instead of comparing across documents. Full snapshots combine Chrome AX data with a bounded DOM fallback across the light DOM, open Shadow DOM, and accessible same-origin child frames; shadow/frame refs retain their root and document identity and fail stale after navigation. Navigation keeps the existing session's ownership of that live tab, but invalidates old refs and may abort a command that was still bound to the previous document. For an action known to navigate, prefer its opt-in `waitForNavigation: true`; otherwise continue with a fresh snapshot or locator in the same session after observing navigation.

`current` and `borrow` never silently create a browser. `create` creates one owned tab and compensates by closing it if session creation fails. Tab, group, element, and generation identifiers are short-lived browser-session identities.

## Approvals

Browser-control and developer-tool commands do not require approval or per-origin authorization. They still enforce Host enablement, authenticated session ownership, tab/document identity, CDP method-name validation, timeout, cancellation, and bounded results. For ENV management, only profile deletion (`env.profiles.delete`, `env.profiles.deleteMany`) is approval-protected. **Host → Agent approvals** is enabled by default; turning it off makes those protected operations execute immediately and clears and hides the pending-approval queue. Creating, updating, enabling, disabling, importing, and reconciling profiles do not require approval in either mode.

When **Agent approvals** is enabled, review the summary and approve or deny the pending operation in the popup's **Host** tab. Clicking **Approve** immediately executes the exact queued request; no token needs to be copied or the command retried. The approval remains single-use and is bound to the client, session, origin, tab generation, main-frame document identity, method, and canonical payload digest. If the extension service worker restarts, the five-minute approval window expires, or the approval switch changes, the queued request is discarded and must be submitted again.

## ENV scopes

Every profile has an explicit target mode:

- **Page filters** — a bounded list of one to 50 exact Tab and/or Group targets. Targets are unioned, so one profile can apply to several individual pages, several tab groups, or both;
- **Tab target** — exact `tabId`, `windowId`, browser generation, URL fingerprint, and main-frame document ID;
- **Group target** — exact `groupId`, `groupTitle`, `windowId`, browser generation, and granted member/document identity set; credential-like group titles are rejected instead of being persisted as identity;
- **Global** — only when explicitly requested and enabled.

Legacy single Tab and Group profile scopes remain accepted and are shown as one page filter in the popup. Page filters never widen to global when a target is missing. Scope precedence is global → group → tab; a mixed page-filter profile uses explicit-page precedence across its union. Tab targets are bound to the selected main-frame document and exact URL fingerprint; before a bridge-triggered navigation the old tab is synchronously excluded from owned DNR rules. Browser navigation and group events start immediate cleanup, but Chrome does not await asynchronous extension event handlers, so a short residual subresource window can remain for externally initiated transitions. Document-bound tab/group rules do not apply to `main_frame`; do not use scoped credential-bearing rules where the residual transition risk is unacceptable. Group targets are bound to the exact granted-member identity set observed at approval, and every member must retain a metadata grant. A missing or changed tab/group target reconciles to `target-missing`; it never widens to global or rebinds by title.

Accepted lanes are exactly `ppe_*`, `boe_*`, or `canary`. Group titles are presentation labels and do not need to match the lane; the live numeric group ID and canonical member identity bind the scope. Lane headers are generated by the compiler and cannot be overridden by a user header rule.

Profiles can contain bounded request/response header, redirect, query, cookie, CSP, and filter rules. A Host session can also install one temporary route with `env.session.apply`: it is bound to that session's claimed tab, requires 1–20 exact HTTP(S) origins, supports a lane and/or non-redirect rules, is installed before the first navigation, and follows that same live tab only while the destination origin remains allowed. `env.session.get` inspects it and `env.session.clear` removes it. Session routes never enter persistent profile CRUD and are removed on session close, lease expiry, Stop all, host disable, or tab removal; cleanup fails closed by clearing owned DNR rules if a targeted update fails.

Host clients can use `env.profiles.deleteMany` to remove a complete ID/revision set atomically under one bound approval; the popup keeps only the per-profile **Remove** action. The popup's **Add rule** flow covers environment headers, request and response headers, redirects, query parameters, cookie request headers, CSP response modifiers, URL and URL-regex filters, request and excluded-request domains, page/initiator domains, request methods, and resource types. When **Tab group** scope is selected for an ungrouped current page, **Current group** becomes **Create group**; the new group title defaults to the first safe non-remove header value, then falls back to the profile name. Each rule card has an **Enabled**/**Disabled** toggle immediately before **Delete**, and every successful rule add, toggle, field edit, JSON edit, or deletion offers **Undo**. Page and tab-group targeting remain in the separate **Scope** selector. The **Rules** section starts collapsed and exposes the formatted raw rule array; valid edits save on blur and invalid edits revert to the last stored value. Non-remove request/response header, cookie, and CSP rules require a direct `value`, stored in the local profile so it remains visible and effective after extension reloads and browser restarts. The removed `env.secrets.*` API and `secretRef` rule field are rejected. During storage migration, legacy `secretRef` rules and their unavailable session-only values are deleted rather than converted to empty modifiers. Sensitive query-parameter names and credential-like values—including Bearer/Basic credentials, JWTs, and established opaque token prefixes—and credential-bearing redirect or filter URLs remain rejected because URLs can escape the controlled header-modification boundary. Detection is shared with output redaction and covers literal, colon-style, percent-encoded, and twice-encoded assignment separators. Regex redirect sources and regex filters containing literal or escaped assignment equals—including percent, hex, Unicode, braced-hex, and octal forms—are rejected, except for regex lookaround syntax; use an exact redirect, a non-regex URL filter, or an explicit non-sensitive query rule instead. Unknown or malformed filter dimensions are rejected rather than silently widened or discarded.

See [docs/api.md](docs/api.md) and [docs/operations.md](docs/operations.md).

## Security boundaries

- The HTTP server listens only on `127.0.0.1` and prefers the popup-configured port (`11451` by default). If that port is occupied, the instance falls back to an ephemeral port recorded in its instance registry entry. Every request still requires the random bearer token from `~/.s-chromium-bridge/config.json` (`0600`); instance and alias registry files never contain that token.
- Instance aliases are user-wide local selection metadata. Registration is an atomic create-only claim, renaming claims the new alias before releasing the old one, and an alias never grants session ownership, browser permission, or ENV scope. An offline or replaced bound instance returns `INSTANCE_UNAVAILABLE`; there is no automatic rebinding.
- Native Messaging stdout contains only 4-byte little-endian framed JSON. Diagnostics use stderr.
- Page content, screenshots, dialog text, bounded console/exception diagnostics, CDP events, and tool output are untrusted.
- Password, OTP, token, secret, Cookie, and Authorization values are not exposed through Host API responses, snapshots, console/network diagnostics, audit entries, or errors. The trusted local extension popup displays configured ENV rule values in plaintext for direct editing, and Popup- or Host-authored modifier values are persisted in the local profile so they survive extension reloads and browser restarts. Audit client/session identifiers are per-install HMAC aliases rather than caller-controlled plaintext. Snapshot nodes deliberately omit form-control and editable values entirely. Network capture can optionally include only parseable JSON request/response bodies within a caller-selected 1–65,536-byte bound; sensitive keys and headers are redacted, and URL filtering occurs before events enter the retained stream.
- Raw CDP is disabled by default and requires the popup's dangerous **Full CDP access** switch. When enabled, `page.cdp.send` accepts every well-formed `Domain.method` command supported by Chrome's `chrome.debugger` transport for the owned tab; Chrome remains the source of truth for protocol-version and target-domain support. Every result is capped at 2 MiB. Turning the switch off releases current debugger attachments, while later high-level Console, Network, PDF, screenshot, accessibility, hover, and dialog operations may still attach internally. Raw commands cannot disable or reconfigure Runtime/Log/Network while the corresponding high-level Console or Network capture owns that lifecycle.
- Screenshot, PDF, and file upload bytes use 256 KiB chunks with a 64 MiB cap, five-minute TTL, exact byte count, SHA-256 verification, browser-generation binding, and client/session ownership.
- The popup's **Stop all** action cancels active work, waits for already-started work to quiesce, releases debugger attachments and sessions, clears transfers, and closes unretained bridge-created tabs.
- Mutating requests are never automatically replayed after an unknown transport result.

## Development

```bash
npm run check
npm run pack:smoke
```

`pack:smoke` packs and globally installs the tarball into a temporary prefix, validates the stable extension ID and manifests, performs a framed Native Messaging hello/ack exchange, verifies backup restoration, and uninstalls the temporary host. It is not a real Chrome/Edge end-to-end test.
