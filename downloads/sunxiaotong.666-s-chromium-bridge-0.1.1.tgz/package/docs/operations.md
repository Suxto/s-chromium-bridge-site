# Operations guide

## Installation and verification

```bash
npm install --global https://suxto.github.io/s-chromium-bridge-site/downloads/sunxiaotong.666-s-chromium-bridge-0.1.1.tgz
s-chromium-bridge install-host --browser all --json
s-chromium-bridge extension-path
```

Load the printed unpacked extension directory in Chrome or Edge. Do not run `native-host.sh` manually: Chromium must launch it with Native Messaging framing and the extension origin.

Run:

```bash
s-chromium-bridge doctor --json
s-chromium-bridge status --json
```

`doctor` validates Node, package artifacts, per-browser Native Messaging manifests, launcher executability, host configuration permissions, and discoverable healthy instances. A host can be installed correctly while no browser instance is online.

## Runtime state

```text
~/.s-chromium-bridge/
├── config.json                    # bearer token, mode 0600
├── install-receipt.json           # manifest backup/restore metadata
├── bin/native-host.sh             # mode 0700
├── instance-aliases/<alias>.json  # user-wide alias reservation, no bearer token
└── instances/<instanceId>.json    # live discovery, no bearer token
```

The HTTP service binds only to `127.0.0.1`. Its preferred port is stored in the extension settings and defaults to `11451`; save another integer from `1` through `65535` in the popup's **Host** tab when needed. A change reconnects the Native Messaging host. If the preferred port is already occupied, that browser instance falls back to an ephemeral port so simultaneous profiles remain usable; the actual port is written to its instance registry entry and returned by the Native Messaging hello acknowledgment. Extension heartbeat is the freshness source. An instance becomes stale after 15 seconds.

Set an optional browser instance alias in the popup's **Host** tab after the Native Host connects. Aliases are lowercase slugs matching `^[a-z0-9][a-z0-9._-]{0,63}$` and are atomically reserved across Chrome, Edge, and all profiles for the current OS user. The alias binds the persistent extension `instanceId`, not a temporary bridge session. Use exactly one selector:

```bash
s-chromium-bridge status --alias work-chrome --json
s-chromium-bridge call browser.tabs.list --alias work-chrome --client my-agent --json
```

`--instance`, `--alias`, and `--browser` are mutually exclusive. If an alias is bound but its exact instance is offline, the CLI returns `INSTANCE_UNAVAILABLE`; it never falls back to another browser or profile. Clearing the alias in that instance's popup releases it. A full `uninstall-host --browser all --purge` also removes alias reservations. When several instances are healthy and no selector is given, the CLI returns `INSTANCE_AMBIGUOUS` rather than guessing.

## Upgrade

`0.1.0` is the first persisted schema (`v1`), so there is no older released profile/settings schema to transform. Unknown or malformed persisted versions fail closed and remain untouched. Shipping any incompatible storage `v2` requires a tested backup, transform, validation, and atomic active-version switch before release.

1. Keep Chrome/Edge open only if preserving the browser session matters.
2. Upgrade the npm package.
3. Run `s-chromium-bridge install-host` again. Reinstallation preserves the original third-party manifest backup receipt.
4. In `chrome://extensions` or `edge://extensions`, reload the unpacked extension from the new `extension-path`.
5. Run `doctor`, then a read-only `status`, session open, tab list, and snapshot smoke test.
6. Review and accept the browser-data disclosure, grant HTTP(S) page access when Chrome prompts, then re-enable only the Host/ENV switches that are needed.

Extension runtime sessions, element references, approvals, and transfer IDs are intentionally invalid after a browser restart or extension reload. Persistent ENV profiles remain, but stale tab/group scopes reconcile to `target-missing` instead of widening.

## Rollback and uninstall

Before upgrading, record the installed package version and keep the previous package tarball if deterministic rollback is required.

To roll back:

1. Disable Host and ENV in the popup.
2. Install the previous package version.
3. Run `install-host` and reload the previous unpacked extension directory.
4. Run `doctor` and `env.reconcile`.

To remove the Native Messaging integration:

```bash
s-chromium-bridge uninstall-host --browser chrome --json
# Only after a full all-browser uninstall, also remove config/token and stale registry entries:
s-chromium-bridge uninstall-host --browser all --purge --json
```

`--browser chrome|edge|all` supports partial install/uninstall without discarding receipts for unselected browsers. `--purge` is accepted only when all recorded browser targets are removed. Uninstall removes only manifests that still match this host name and fixed extension origin. If installation displaced an unrelated manifest, the exact managed backup recorded at install time is restored. An unrelated manifest written later is never overwritten during uninstall. Remove the unpacked extension separately in the browser UI.

## ENV consistency and recovery

Persistent profiles in `chrome.storage.local` are the source of truth. DNR session rules are derived and use only IDs `800000–899999`.

Mutation flow:

1. Validate and stage a revisioned profile under a short local state lock.
2. Release the state lock.
3. Compile the latest generation using current tabs, groups, and persisted modifier values.
4. Replace owned DNR rules and read them back for canonical verification.
5. Commit `applied` status only if the profile generation is still current; otherwise reconcile the newer generation.
6. On failure, restore and verify the prior owned rule set. If both apply and recovery fail, return `INTERNAL` and keep profiles as the recovery source.

Unknown or malformed persisted ENV/settings/session state is preserved for recovery where applicable, but reconciliation first removes and verifies removal of every owned DNR session rule before reporting the failure; invalid source data cannot leave prior enforcement active. Tab profiles bind their main-frame document ID and URL fingerprint. Before bridge-triggered navigation, DNR exclusion is awaited before the browser navigation starts. Browser navigation and group events begin immediate fail-closed cleanup, but Chrome does not await asynchronous extension event handlers; a short residual transition window can remain for user/page-initiated navigation or group changes. Document-scoped rules never target `main_frame`. Do not use tab/group-scoped credential-bearing rules where that residual subresource window is unacceptable. Group profiles bind the exact metadata-granted member/document identity set. Reconciliation disables stale targets as `target-missing` rather than widening scope.

Temporary Session ENV is a separate, explicit route owned by one authenticated session and one claimed tab. Apply it before `page.navigate`, with 1–20 exact HTTP(S) origins and a lane and/or non-redirect rules. Its generated origin regex remains authoritative, so rule-level URL/regex filters are rejected. Unlike persistent document-bound profiles, it can target `main_frame` and follows navigation of the same live tab only while the destination origin remains allowed. It is stored in `chrome.storage.session`, omitted from popup profile CRUD, and removed on session close, lease expiry, Stop all, host disable, or tab removal. Lifecycle cleanup is serialized with profile mutations; a failed targeted DNR update triggers verified removal of all bridge-owned rules before cleanup proceeds.

Run a manual repair after a browser crash, extension reload, or DNR conflict:

```bash
s-chromium-bridge call env.reconcile --params '{}' --json
```

If a tab/group target disappeared, inspect the profile in the popup. It remains disabled as `target-missing`. Create or update an explicitly scoped profile after selecting the new target; do not edit storage or infer a new target by title.

Each rule card exposes an **Enabled**/**Disabled** toggle immediately before **Delete**. Successful rule additions, toggles, key/value edits, Advanced JSON edits, and deletions show an **Undo** action; starting another rule edit invalidates the previous Undo so stale snapshots cannot overwrite newer work.

Popup-authored and Host-authored request/response header, query, cookie, and CSP values are stored directly in the local profile, so they remain visible in the trusted Popup and effective after extension reloads and browser restarts. Host-facing responses continue to redact those fields as `configured: true`. Query names and values are additionally rejected when they resemble credentials because URL-carried data can escape through logs, history, referrers, or diagnostics. The `env.secrets.*` API and `secretRef` rule field are no longer supported. On first storage read after upgrade, rules carrying a legacy `secretRef` are deleted, the obsolete session value map is cleared, and DNR is reconciled from the remaining rules. Re-enter any removed value as a direct rule value if that modifier is still needed.

### Legacy ENV-Plugin JSON import

The bridge never reads another extension's private storage. Export or construct the documented subset yourself, then preview it:

```bash
# legacy-import.json contains {"document":{"profiles":[...]}}
s-chromium-bridge call env.migration.preview --params @legacy-import.json --json
```

The preview resolves tab/group IDs against the live browser, rejects ambiguous scope, reports omitted credential-bearing rules, and imports explicit global profiles as disabled. After reviewing the complete preview, call `env.migration.import` with `{"previewToken":"<token from preview>"}`; import does not require a separate approval. The single-use preview token is bound to the client, browser generation, normalized document, and live target fingerprints; import fails if any target changed. Import stages all profiles in one storage generation and performs one DNR reconciliation; a failure does not widen any scope.

## Approval recovery

Pending approvals live in browser session storage, are capped at 50, and expire after five minutes. **Host → Agent approvals** is enabled by default. Turning it off clears pending requests, hides the approval panel, and lets otherwise protected profile deletions execute immediately; turning it back on protects future requests. If an enabled-approval command reports `approvalRequired`:

1. Review the redacted, labeled action summary returned with the error or shown in the popup.
2. Approve or deny it locally.
3. **Approve** immediately executes the exact queued request; there is no token to copy and no manual retry.

The queued request is held only in extension memory. An extension reload, service-worker restart, explicit **Stop all**, or expiry discards it; submit the command again to create a fresh review. Before execution, the bridge still revalidates the bound client, session, tab/document generation, group membership, method, payload digest, and current ENV revisions. A changed or already executed request fails closed instead of being replayed.

## Timeout, cancellation, and unknown outcomes

A timeout returns `DEADLINE_EXCEEDED`; explicit cancellation returns `CANCELLED`. The caller-facing HTTP request settles as soon as that terminal state is recorded and cancellation is dispatched; it never waits indefinitely for a cooperative extension response. The host keeps a bounded wire tombstone and in-flight slot until the extension acknowledges the late response or a five-second cancellation grace expires, so late results are discarded without prematurely increasing native concurrency. Chrome APIs are not universally cancellable, and a mutation may already have reached the browser. Therefore:

- do not automatically retry mutations;
- inspect current browser/profile state first;
- retry only when the response has `retryable: true` and acceptance is known not to have occurred;
- use a new inventory reference after any identity uncertainty.

`TAB_IDENTITY_CHANGED` is independent of the **Full CDP access** switch. Enabling or disabling that switch only gates raw calls and, when disabled, releases current debugger attachments; it does not rotate a tab identity. Full-document navigation, SPA `history.pushState`/`replaceState`, and fragment navigation rotate the bridge tab generation so the command bound to the old document may fail with `TAB_IDENTITY_CHANGED`; old snapshots, refs, and approvals are invalid. Active bounded Console and Network streams remain session-owned across allowed navigation and keep each event's document identity. The session still owns the same live tab. For `page.click`, `page.doubleClick`, or `page.press` that is known to navigate, set `waitForNavigation: true` so listeners are installed before the action and the exact request waits for both action and main-frame commit/history/fragment completion. Do not set it speculatively: a non-navigating action will wait until the request deadline. After an unanticipated navigation, do not repeat an uncertain mutation and do not create a replacement tab or close/re-borrow the session. Instead, issue a fresh `page.snapshot` or locator operation in the same session and continue from the new document. Stop and report if that fresh operation cannot revalidate the exact owned tab, for example after tab removal, restricted navigation, or browser restart.

Read-only callers may reuse the same request ID for a single transport retry only when the host proves the extension did not accept the first request.

## Debugger cleanup

Accessibility snapshots use ephemeral debugger attachments unless the same session already owns a network or console attachment. Network capture, console diagnostics, and dialog state are bounded and session-owned. Network and console capture may share one debugger attachment; stopping one does not interrupt the other. Active network and console capture follow full-document, SPA-history, and fragment navigation on the same owned tab, and each retained event keeps its document identity; other temporary debugger uses are released when no capture remains. Session close, tab removal, ownership loss, debugger detach, and explicit stop release state. If Chrome reports another debugger owner, close DevTools/other automation or stop that session; the bridge fails with `DEBUGGER_BUSY` and does not steal the target.

Dedicated `page.console.read` output contains bounded, redacted `console.*` calls, uncaught exceptions, and browser log entries. `page.errors.read` filters that same active stream to uncaught exceptions, `console.error`/failed assertions, and error-level log entries while advancing its cursor past non-errors. The shared stream omits live CDP object handles, retains at most 1,000 events and 2 MiB, and reports when an older cursor was truncated. Dedicated `page.network.read` output contains bounded metadata and redacted request/response headers. `page.network.start` can add a literal URL substring filter and opt into parseable JSON request/response bodies bounded to 1–65,536 bytes; sensitive keys, Cookie, Authorization, and other sensitive headers are replaced, while oversized, non-JSON, and non-JSON-content-type bodies are omitted. Raw `page.cdp.send` is disabled by default and fails with `PERMISSION_DENIED` until the user enables the popup's dangerous **Full CDP access** switch. When enabled, authenticated Host sessions may use any well-formed `Domain.method` supported by Chrome on the owned tab; raw CDP results are capped at 2 MiB. The switch does not disable the high-level APIs or their bounded internal debugger use. High-level Console and Network capture retain lifecycle ownership, so raw commands cannot disable or reconfigure their active Runtime, Log, or Network domains. Raw CDP may expose sensitive browser or page state; do not request credentials or persist sensitive results.

## Transfer recovery

Transfers use IndexedDB, four active slots, five-minute TTL, 256 KiB indexed chunks, a 64 MiB cap, and exact commit verification.

- Duplicate or out-of-range chunks return a conflict/validation error.
- A failed or cancelled upload clears page-side temporary data and deletes the transfer.
- Disabling Host or using popup **Stop all** cancels active requests and clears all transfers.
- Expired transfers are deleted during later transfer activity.
- Extension reload may preserve IndexedDB bytes, but caller/session ownership and browser identity still apply; begin a new transfer when ownership is uncertain.
- Delete completed download transfers after consuming all chunks.

## Real browser E2E checklist

Pack smoke is not browser E2E. Before release, verify separately in both Chrome and Edge where available:

1. Native host connection, heartbeat, disconnect, and reconnect.
2. Multiple browser instances fail ambiguous without a selector; `--instance` and `--alias` select only the exact healthy instance, alias conflicts fail, and an offline alias returns `INSTANCE_UNAVAILABLE` without fallback.
3. `current`, `borrow`, and `create` sessions; exact inventory-claim rejection after target mutation, same-session continuity after SPA/full navigation, and ownership loss after tab removal.
4. AX/DOM merged snapshot including open Shadow DOM, Select/Table/Dialog/portal fallbacks, and accessible same-origin child frames; stale refs after navigation; fresh same-session snapshot; direct click/fill/select/table execution; and cancel/timeout.
5. Screenshot/PDF transfer digest and multi-chunk upload.
6. Dialog and download wait with origin binding.
7. Network metadata bounds and guaranteed debugger detach.
8. Persistent ENV tab, exact group, and explicit global scope; Session ENV before first navigation, allowed/disallowed origin transitions, and cleanup on close/expiry/Stop all/tab removal; target removal and startup reconcile.
9. DNR partial-apply simulation and verified rollback.
10. Upgrade, previous-manifest restoration, and uninstall ownership checks.

Record actual browser versions and distinguish real E2E evidence from mocked tests, type checks, builds, and pack smoke.
