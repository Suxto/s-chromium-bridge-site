# API reference

All requests use protocol version `1` and are sent through the CLI or `POST /v1/rpc`.

```json
{
  "protocolVersion": 1,
  "id": "caller-stable-request-id",
  "clientId": "my-agent",
  "sessionId": "optional-session-id",
  "method": "system.status",
  "params": {},
  "timeoutMs": 15000
}
```

The HTTP endpoint requires `Authorization: Bearer <token>`. The CLI reads the token locally; callers should not print or persist it. The default timeout is 15 seconds and the maximum is 120 seconds for every request, including transfer-oriented and download-wait operations.

## System and sessions

| Method                | Important parameters                                                          | Notes                                                                      |
| --------------------- | ----------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| `system.ping`         | —                                                                             | Liveness and protocol version.                                             |
| `system.status`       | —                                                                             | Extension/host status and bounded queue state.                             |
| `system.capabilities` | —                                                                             | Runtime capability names.                                                  |
| `session.open`        | `mode: current\|borrow\|create`, optional `inventoryRef`, `url`, `groupTitle` | `borrow` requires a fresh inventory reference from `browser.tabs.list`.    |
| `session.list`        | —                                                                             | Only sessions owned by the caller's `clientId`.                            |
| `session.close`       | request `sessionId`                                                           | Releases debugger state and closes unretained tabs created by the session. |
| `session.retain`      | `tabId`, `retention: none\|deliverable\|handoff`                              | Changes close-on-session-end behavior.                                     |

A session lease is 30 minutes. A tab may have only one interacting owner. Browser navigation changes its document generation and invalidates prior element references, snapshot baselines, and approvals, while the existing session keeps ownership of that live tab. Active bounded Console and Network streams remain session-owned across allowed navigation and keep per-event document identity; explicit stop, ownership loss, session close, or tab removal releases them. A command already bound to the old generation may return `TAB_IDENTITY_CHANGED`; continue with a fresh snapshot or locator in the same session rather than creating or borrowing a replacement tab. Tab removal, restricted navigation, browser restart, or extension reload still invalidates ownership fail closed.

## Browser inventory

- `browser.tabs.list`
- `browser.tabs.get` — `tabId`
- `browser.tabs.active`
- `browser.tabs.create` — optional `url`, `active`
- `browser.tabs.close` — optional `tabId`
- `browser.tabs.claim` — `inventoryRef`
- `browser.groups.list`
- `browser.groups.get` — `groupId`
- `browser.windows.list`

Tab inventory references expire after 30 seconds and bind the observed tab ID, window ID, URL, title, and generation. Group responses include the real numeric `groupId` and a bounded, redacted `groupTitle`; no cross-extension title inference is used. Credential-like group titles cannot be used as persistent ENV scope identity and are rejected during create, update, or migration.

## Page operations

All page methods require an owned tab in an authenticated Host session. HTTP(S) access is automatic; pass `tabId` to select an owned tab, otherwise the session's current tab is used.

| Method                                                   | Parameters                                                                | Approval                                  |
| -------------------------------------------------------- | ------------------------------------------------------------------------- | ----------------------------------------- |
| `page.navigate`                                          | `url`                                                                     | No                                        |
| `page.reload`                                            | optional `bypassCache`                                                    | No                                        |
| `page.back`, `page.forward`                              | —                                                                         | No                                        |
| `page.snapshot`                                          | optional `mode: full\|diff`, `maxNodes`                                   | No                                        |
| `page.snapshot.diff`                                     | optional `maxNodes`; compares with the last same-session snapshot         | No                                        |
| `page.locate`                                            | `locator`; optional `limit`                                               | No                                        |
| `page.click`, `page.doubleClick`                         | `locator`, `ref`, or fallback `selector`; optional `waitForNavigation`    | No                                        |
| `page.fill`, `page.type`                                 | target plus `value`                                                       | No                                        |
| `page.focus`, `page.hover`, `page.check`, `page.uncheck` | target                                                                    | No                                        |
| `page.select`                                            | target plus exactly one of `value`, exact `label`, or substring `query`   | No                                        |
| `page.table.read`                                        | target; optional `maxRows` (1–200), `maxColumns` (1–50)                   | No                                        |
| `page.pagination`                                        | `direction: next\|previous`; optional explicit target and navigation wait | No                                        |
| `page.scroll`                                            | optional target, `deltaX`, `deltaY`                                       | No                                        |
| `page.press`                                             | `key`; optional target, modifiers, and `waitForNavigation`                | No                                        |
| `page.wait`                                              | bounded condition and timeout parameters                                  | No                                        |
| `page.screenshot`                                        | optional `format`, `quality`                                              | No                                        |
| `page.upload`                                            | target plus committed `transferId`                                        | No                                        |
| `page.download.wait`                                     | `downloadId`, optional `timeoutMs`                                        | No; same-origin association is required   |
| `page.dialog.get`                                        | —                                                                         | No                                        |
| `page.dialog.respond`                                    | `accept`, optional `promptText`                                           | No                                        |
| `page.pdf`                                               | bounded print options                                                     | No                                        |
| `page.network.start/read/stop`                           | optional URL filter and bounded JSON bodies; cursor/limit on read         | No                                        |
| `page.console.start/read/stop`                           | bounded cursor/limit fields                                               | No                                        |
| `page.errors.read`                                       | cursor and optional `limit` after console capture starts                  | No                                        |
| `page.cdp.send`                                          | `cdpMethod`, optional `cdpParams`                                         | Popup **Full CDP access** must be enabled |

`page.snapshot` obtains a bounded Chrome accessibility tree and merges it with bounded DOM fallback metadata. The DOM walk covers the light DOM, open Shadow DOM, Select/Table/Dialog/ARIA modal fallbacks, and script-accessible same-origin child frames. Closed shadow roots and inaccessible/cross-origin frames are intentionally omitted. Shadow refs encode each unique host selector; frame refs bind the exact `frameId` and `documentId`, and actions inject into that document before execution. Form-control and editable values are never returned; interaction uses explicit `fill`/`type` payloads. A `ref` is valid only for the same tab generation and snapshot retention window. CSS selectors are an explicit fallback, not a stable identity.

High-level target methods accept exactly one of `locator`, `ref`, or `selector`. A semantic locator has the form `{"role":"button","name":"Save","label":"Save changes","placeholder":"Search","text":"Save draft","testId":"save-button","exact":false,"states":["visible"],"nth":0,"maxNodes":500}`. At least one of `role`, accessible `name`, `label`, `placeholder`, visible non-editable `text`, `testId`, or `states` is required. Text matching is whitespace-normalized and case-insensitive; it is substring-based unless `exact` is true. Multiple supplied fields are ANDed. Actions are strict: one match is required unless `nth` explicitly selects an occurrence. Missing and ambiguous matches return `LOCATOR_NOT_FOUND` and `LOCATOR_AMBIGUOUS`; a truncated search is reported in error details instead of silently broadening the target. `page.locate` returns bounded actionable matches and fresh refs without exposing form values. Locators can resolve open-shadow and accessible same-origin frame nodes returned by the fresh snapshot. `page.hover` remains main-frame-only because child-frame coordinate translation is not exposed. `page.check`/`page.uncheck` are idempotent. `page.select` selects an exact option value/label or requires a unique case-insensitive substring `query`. `page.table.read` returns bounded redacted headers/rows. `page.pagination` clicks an explicit target, or uses a strict visible/enabled button locator for the requested `next`/`previous` direction.

When a click, double-click, or key press is expected to navigate the main frame, pass `"waitForNavigation": true`. The bridge registers commit, SPA history, fragment, and failure listeners before performing the action, keeps that exact request alive across the expected generation rotation, waits for both the action and navigation signal, refreshes the existing session's live-tab identity, and returns a `navigation` object. Do not set it for actions that are not expected to navigate: the request will wait until its normal deadline. A timeout or transport loss still has an unknown mutation result and must not be blindly replayed.

Example:

```json
{
  "locator": { "role": "button", "text": "Save", "testId": "save-button" },
  "waitForNavigation": true
}
```

`page.snapshot.diff` creates a new snapshot and compares it with the latest snapshot from the same session, tab, and document generation. It returns occurrence-aware `added`, `removed`, and `changed` entries, plus focus, redacted URL, and title transitions. On the first call or after a document-generation change, `baseline: true` is returned and all current nodes are `added`; old-document content is never compared or rebound. `partial: true` means either side was truncated. Previous refs are omitted because they are stale; refs in current `added`, `changed[].after`, and `focus.after` entries belong to the new snapshot. Legacy `page.snapshot` with `mode: "diff"` remains supported.

`page.network.start` accepts optional `urlFilter` (a literal substring, at most 2,048 characters), `captureJsonBodies` (default `false`), and `maxBodyBytes` (1–65,536; default 16 KiB). The filter is applied to the unredacted request URL before an event enters the bounded stream. Headers are always redacted. With body capture enabled, only valid JSON with a JSON content type and within the byte bound is parsed; sensitive keys are redacted, oversized/non-JSON bodies are omitted, and response capture is attempted only when the reported encoded size is within the bound. The network stream remains attached across full-document and same-document navigation of the same owned tab, and is still released by stop, session close, tab removal, or ownership loss.

`page.console.start` enables a session-owned capture stream for `Runtime.consoleAPICalled`, `Runtime.exceptionThrown`, and `Log.entryAdded`. It returns a baseline cursor; pass that cursor to `page.console.read` with an optional `limit` from 1 to 500. `page.errors.read` uses the same cursor stream but returns only uncaught exceptions, `console.error`/failed assertions, and error-level browser log entries; it advances past retained non-error entries so polling does not repeatedly scan them. Entries include the bound `documentId`, bounded primitive argument summaries, redacted source URLs, stack locations, and exception descriptions. Object handles and live object IDs are not exposed. The stream retains at most 1,000 events and 2 MiB per tab; `truncated: true` means the requested cursor predates retained data. `page.console.stop` disables Runtime/Log capture and releases the debugger attachment unless the same session still has network capture active.

Raw CDP is disabled by default. An authenticated Host session may call `page.cdp.send` only after the user enables the popup's dangerous **Full CDP access** switch; otherwise the call fails with `PERMISSION_DENIED`. The switch does not block the bridge's high-level APIs, even when those APIs use a bounded internal debugger attachment. Raw CDP does not require a per-operation approval after the switch is enabled. It accepts every well-formed `Domain.method` command supported by Chrome's `chrome.debugger` transport for the owned tab. Chrome is the source of truth for protocol-version and target-domain support; unsupported commands return the browser error. Results are capped at 2 MiB.

High-level capture lifecycle remains authoritative: `Runtime.disable` and `Log.disable` are rejected while `page.console` capture is active, and raw `Network.enable/disable` are rejected while `page.network` capture is active. Outside those conflicts, the raw methods are passed through. `Runtime.evaluate` and storage, cookie, authentication, debugger, profiler, emulation, tracing, input, and target commands may expose or mutate sensitive browser/page state. Callers must use only the owned HTTP(S) target required by the task, must not request credentials, and must not persist sensitive results.

## Transfers

| Method            | Parameters                                          |
| ----------------- | --------------------------------------------------- |
| `transfer.begin`  | `name`, `mimeType`, `totalBytes`, lowercase SHA-256 |
| `transfer.chunk`  | `transferId`, zero-based `index`, `dataBase64`      |
| `transfer.commit` | `transferId`                                        |
| `transfer.read`   | `transferId`, `index`                               |
| `transfer.delete` | `transferId`                                        |

Chunks are exactly 256 KiB except the final chunk. Transfer IDs are bound to the creating `clientId`, optional `sessionId`, and browser generation. If a session is supplied, every transfer operation also verifies that the live session is still owned by the caller. Maximum total size is 64 MiB, maximum active transfers is four, and TTL is five minutes. Commit verifies chunk count, byte count, and SHA-256. Screenshot and PDF methods return a download transfer descriptor with `id`, `name`, `mimeType`, `totalBytes`, `chunkCount`, and `sha256`; callers read indices `0..chunkCount-1` and should verify both byte count and digest before deleting the transfer.

## ENV

- `env.session.apply` — session ID plus `origins` (1–20 exact HTTP(S) origins) and a lane and/or rules; installs a temporary tab-bound route before navigation
- `env.session.get` — returns the caller-owned temporary route
- `env.session.clear` — removes the caller-owned temporary route
- `env.profiles.list`
- `env.profiles.get` — `id`
- `env.profiles.create` — `profile`
- `env.profiles.update` — `id`, `expectedRevision`, `profile`
- `env.profiles.enable` / `env.profiles.disable` — `id`, `expectedRevision`
- `env.profiles.delete` — `id`, `expectedRevision`
- `env.profiles.deleteMany` — `profiles: [{ id, expectedRevision }]`; validates the complete unique set before atomically deleting it and reconciling DNR once
- `env.rules.list` — `profileId`
- `env.targets.list`
- `env.migration.preview` — `document`; returns an immutable, expiring `previewToken`
- `env.migration.import` — `previewToken`; batch import of exactly the previewed state
- `env.reconcile`

Session ENV routes live only in `chrome.storage.session`, never appear in persistent profile CRUD, and require the ENV switch to be enabled. Their origin allowlist is authoritative: redirects and per-rule `urlFilter`/`regexFilter` are rejected. The route follows the same live claimed tab across navigation only for allowed origins, may include `main_frame`, and is removed on session close, lease expiry, Stop all, host disable, or tab removal. Cleanup is serialized with persistent ENV mutation; if targeted DNR removal fails, the bridge clears all owned DNR rules before allowing lifecycle cleanup to finish.

Profiles accept either `scope: { "kind": "global" }`, a legacy single `tab`/`group` scope, or a bounded page-filter union:

```json
{
  "kind": "filters",
  "targets": [
    { "kind": "tab", "tabId": 42 },
    { "kind": "group", "groupId": 7 }
  ]
}
```

Create/update callers supply only each live numeric target ID; the extension replaces caller metadata with canonical browser generation, window, document, URL fingerprint, group title, and group-member identity before mutation. One to 50 unique targets are allowed. All targets must retain metadata and browser host permission. A group title is only a presentation label and does not need to match the profile lane; scope is bound to the live numeric group ID and canonical member/document identity. The compiled DNR condition uses the union of the selected tab and group member IDs. Missing or changed targets fail closed and never widen the profile to global.

ENV profile creation, update, enable/disable, import, and reconciliation execute without a separate approval. Profile deletion (`env.profiles.delete`, `env.profiles.deleteMany`) is protected when the popup's **Agent approvals** switch is enabled, which is the backward-compatible default. Turning the switch off clears pending approvals, hides the approval panel, and lets protected deletion execute immediately; re-enabling it protects future requests. The initial `PERMISSION_DENIED` response for a protected operation includes a redacted human-readable review summary. The popup renders that summary as labeled lines instead of raw JSON, and **Approve** immediately executes the exact queued request without exposing or copying an approval token. Bulk deletion uses one approval bound to the complete ordered ID/revision set and cannot authorize a subset, superset, reordered payload, or a second deletion. If the extension service worker restarts, the five-minute window expires, or the approval switch changes, the in-memory queued request is discarded and must be submitted again. The Modifier master switch controls only whether enabled profiles are compiled into active request rules; profile create, edit, enable, disable, delete, and migration remain available while injection is paused. Delete approval summaries include the affected profile name and every target. Tab targets bind the exact tab/window, browser generation, URL fingerprint, and main-frame document ID; before bridge-triggered navigation the old tab is synchronously excluded from owned DNR rules. Browser navigation and group events start immediate cleanup, but Chrome does not await asynchronous extension listeners, so a short residual subresource window can remain for externally initiated transitions. Document-bound tab/group rules do not target `main_frame`; scoped credential-bearing rules are unsuitable when that residual transition risk is unacceptable. Group targets require every current member to have both the bridge metadata grant and browser host permission and bind the complete member/document fingerprint. Updates use revision compare-and-swap. DNR is derived state; profiles are the source of truth. Owned session-rule IDs are restricted to `800000–899999`. Non-remove request/response header, cookie, and CSP rules require a direct `value`, stored in the local profile so it survives extension reloads and browser restarts.

Direct modifier values are stored in the local profile and shown by the trusted Popup after extension reloads and browser restarts. Host-facing list/get/mutation responses still replace request/response header, query, cookie, and CSP values with `configured: true`. The removed `env.secrets.*` methods and `secretRef` rule field return `METHOD_NOT_FOUND` and `INVALID_PARAMS`, respectively. Storage migration deletes legacy `secretRef` rules, clears their obsolete session value map, advances the profile/store generation, and forces DNR reconciliation; it never converts a missing value into an empty modifier. When a profile declares a lane, `x-tt-env` and `x-use-ppe` are reserved for the lane compiler and cannot also be set or removed by user header rules. Sensitive query-parameter rules and credential-bearing redirects, URL filters, or regex filters remain rejected because those rule forms can leak values through URLs; detection includes literal, colon-style, percent-encoded, and twice-encoded assignment separators. Regex redirect sources and regex filters cannot contain literal or escaped assignment equals—including percent, hex, Unicode, braced-hex, and octal forms—outside regex lookaround syntax; use exact/non-regex matching or a separate non-sensitive query rule. Legacy import accepts a documented subset of ENV-Plugin-shaped JSON under `document.profiles`: `headers`, `respHeaders`, `redirects`, `queries`, `cspRules`, shared filters, `tabFilters`, `tabGroupFilters`, and explicit global state. Run `env.migration.preview` first, review the normalized result, then pass its `previewToken` to `env.migration.import`. The token is single-use, expires after five minutes, and is bound to the caller, browser generation, normalized document, and live tab/group identities. Numeric string runtime IDs are normalized only after exact validation. Legacy import still omits plaintext headers, cookies, sensitive query names, credential-like query values (including Bearer/Basic credentials, JWTs, and established opaque token prefixes), and credential-bearing URL rules rather than silently widening their exposure. The bridge never reads another extension's private storage.

## Errors and retries

Errors have stable `code`, safe `message`, `retryable`, and optional redacted `details`. Common categories:

- validation/protocol: `INVALID_REQUEST`, `INVALID_PARAMS`, `PROTOCOL_INCOMPATIBLE`;
- policy: `PERMISSION_DENIED`, `HOST_DISABLED`, `ENV_BRIDGE_DISABLED`, `SITE_NOT_ALLOWED`; `page.cdp.send` returns `PERMISSION_DENIED` while popup **Full CDP access** is off;
- identity/targeting: `INSTANCE_UNAVAILABLE`, `TAB_NOT_OWNED`, `TAB_IDENTITY_CHANGED`, `LOCATOR_NOT_FOUND`, `LOCATOR_AMBIGUOUS`, `STALE_ELEMENT`, `SESSION_NOT_FOUND`;
- concurrency: `QUEUE_FULL`, `DEBUGGER_BUSY`, `CONFLICT`;
- lifecycle: `DEADLINE_EXCEEDED`, `CANCELLED`;
- size: `RESULT_TOO_LARGE`.

Only retry when `retryable` is true. Never automatically replay a mutation after timeout, connection loss, or an otherwise unknown acceptance result.
